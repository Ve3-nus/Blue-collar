import api from "./axios";

export const getSkills = () =>
  api.get("/worker_skills");

export const addSkill = (data) =>
  api.post("/worker_skills", data);

export const removeSkill = (id) =>
  api.delete(`/worker_skills/${id}`);