import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "../context/AuthContext";
import ProtectedRoute from "../components/ProtectedRoute";
import Layout from "./components/Layout";
import "./App.css";

// Public pages
import Login from "../pages/Login";
import Register from "../pages/Register";

// Shared pages
import Dashboard from "../pages/Dashboard";
import JobsPage from "./pages/JobsPage";
import JobDetailPage from "./pages/JobDetailPage";
import MyApplicationsPage from "./pages/MyApplicationsPage";
import NotificationsPage from "./pages/NotificationsPage";
import WorkersPage from "./pages/WorkersPage";

// Customer pages
import MyJobsPage from "./pages/customer/MyJobsPage";
import PostJobPage from "./pages/customer/PostJobPage";

// Worker pages
import WorkerProfilePage from "./pages/worker/WorkerProfilePage";

// Admin pages
import AdminUsersPage from "./pages/admin/AdminUsersPage";
import AdminJobsPage from "./pages/admin/AdminJobsPage";
import AdminApplicationsPage from "./pages/admin/AdminApplicationsPage";
import AdminReviewsPage from "./pages/admin/AdminReviewsPage";
import AnalyticsPage from "./pages/admin/AnalyticsPage";

const P = ({ children, role }) => (
  <ProtectedRoute role={role}>
    <Layout>{children}</Layout>
  </ProtectedRoute>
);

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Public */}
          <Route path="/" element={<Login />} />
          <Route path="/register" element={<Register />} />

          {/* All authenticated roles */}
          <Route path="/dashboard" element={<P><Dashboard /></P>} />
          <Route path="/jobs" element={<P><JobsPage /></P>} />
          <Route path="/jobs/new" element={<P role="customer"><PostJobPage /></P>} />
          <Route path="/jobs/:id" element={<P><JobDetailPage /></P>} />
          <Route path="/my-applications" element={<P><MyApplicationsPage /></P>} />
          <Route path="/notifications" element={<P><NotificationsPage /></P>} />
          <Route path="/workers" element={<P><WorkersPage /></P>} />
          <Route path="/workers/:id" element={<P><WorkerProfilePage /></P>} />

          {/* Customer */}
          <Route path="/my-jobs" element={<P role="customer"><MyJobsPage /></P>} />

          {/* Worker */}
          <Route path="/profile" element={<P role="worker"><WorkerProfilePage /></P>} />

          {/* Admin */}
          <Route path="/admin/users" element={<P role="admin"><AdminUsersPage /></P>} />
          <Route path="/admin/jobs" element={<P role="admin"><AdminJobsPage /></P>} />
          <Route path="/admin/applications" element={<P role="admin"><AdminApplicationsPage /></P>} />
          <Route path="/admin/reviews" element={<P role="admin"><AdminReviewsPage /></P>} />
          <Route path="/analytics" element={<P role="admin"><AnalyticsPage /></P>} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
