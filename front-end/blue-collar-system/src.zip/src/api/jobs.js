import api from "./axios";

export const registerUser = (data) =>
  api.post("/register", data);

export const loginUser = async (data) => {
  const response = await api.post(
    "/login",
    data
  );

  return response.data;
};

export const getCurrentUser = () =>
  api.get("/me");